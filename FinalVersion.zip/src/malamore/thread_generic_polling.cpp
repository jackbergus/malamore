#include "malamore.h"
#include <malamore/thread_generic_polling.h>

#include <iostream>
#include <intrin.h>

// Svuota la coda condivisa IPC pre-caricando i messaggi a lunghezza variabile nella mappa di ingresso
static void PreloadCoreInput(void* pInChannel, MessageInputMap& inMap) {
    if (!pInChannel) return;

    KernelBufferChannel inputChannel(pInChannel);
    BinderParcel packet = {0};

    while (inputChannel.Read(&packet, sizeof(BinderParcel)) > 0) {
        if (packet.CommandType == CMD_SIGNAL_NODE && packet.DataLength > 0) {
            ULONG senderId = static_cast<ULONG>(packet.SourceNodeName[0]); // ID numerico estratto

            MSG2 msg;
            msg.Dimension = packet.DataLength;
            msg.Buffer.assign(packet.PayloadData, packet.PayloadData + packet.DataLength);

            inMap[senderId] = msg;
        }
    }
}

// Svuota la mappa in uscita (iovec) inviando i messaggi generati verso la coda condivisa a valle
static void FlushCoreOutput(void* pOutChannel, MessageOutputMap& outMap, const std::string& nodeName) {
    if (!pOutChannel || outMap.empty()) return;

    KernelBufferChannel outputChannel(pOutChannel);

    for (auto& [targetId, msg] : outMap) {
        if (msg.Dimension == 0 || msg.Buffer.empty()) continue;

        BinderParcel packet = {0};
        packet.CommandType = CMD_SIGNAL_NODE;
        strcpy_s(packet.SourceNodeName, 64, nodeName.c_str());

        packet.PayloadData[0] = static_cast<UCHAR>(targetId);

        ULONG bytesToCopy = (msg.Dimension < (sizeof(packet.PayloadData) - 1)) ? msg.Dimension : (sizeof(packet.PayloadData) - 1);
        std::memcpy(&packet.PayloadData[1], msg.Buffer.data(), bytesToCopy);
        packet.DataLength = bytesToCopy + 1;

        outputChannel.Write(&packet, sizeof(BinderParcel));
    }
    outMap.clear();
}

/**
 * CORE POLLING ROUTINE GENERIC (TANDEM ARCHITECTURE WITH BUSY-WAIT TIMING YIELD)
 */
void CorePollingRoutineGeneric(CorePollingContext* context) {
    if (!context || !context->pSharedParcelAddress) return;

    HANDLE hCurrentThread = GetCurrentThread();
    LARGE_INTEGER startTicks, currentTicks, nextPeriodTicks;

    MessageInputMap inputMap;
    MessageOutputMap outputMap;

    // Sincronizzazione iniziale del clock hardware come nel tuo codice originale
    QueryPerformanceCounter(&startTicks);
    nextPeriodTicks.QuadPart = startTicks.QuadPart + context->PhaseOffsetTicks; // Gestione sfasamento temporale per l'alternanza

    // CICLO CORE PRINCIPALE DETERMINISTICO INTERCONNESSO
    while (InterlockedRead(&context->KeepRunning)) {

        // =========================================================================
        // ARCHITETTURA A TANDEM: IL TASK ENTRA IN YIELDING COOPERATIVO
        // =========================================================================
        do {
            YieldProcessor(); // Cede la pipeline hardware senza rilasciare il core (_mm_pause / ror)
            QueryPerformanceCounter(&currentTicks);
        } while (currentTicks.QuadPart < nextPeriodTicks.QuadPart &&
                 InterlockedRead(&context->KeepRunning));

        if (!InterlockedRead(&context->KeepRunning)) break;

        // =========================================================================
        // FINESTRA DETERMINISTICA ISOLATA (ELEVATION IN BASE ALLA CONFIGURAZIONE)
        // =========================================================================
        int currentPriority = InterlockedRead(&context->IsHighPriority);
        if (currentPriority == 1) {
            SetThreadPriority(hCurrentThread, THREAD_PRIORITY_TIME_CRITICAL); // Massima priorità Realtime (Livello 31)
        } else {
            SetThreadPriority(hCurrentThread, THREAD_PRIORITY_NORMAL);        // Priorità standard per Task degradato
        }

        // STADIO DI PRE-CARICAMENTO CODA CONDIVISA I/O (INGRESSO)
        inputMap.clear();
        PreloadCoreInput(context->pInChannelAddress, inputMap);
        outputMap.clear();

        // Cronometraggio del Task tramite Performance Counter nativi
        LARGE_INTEGER taskStart, taskEnd;
        QueryPerformanceCounter(&taskStart);

        // ESECUZIONE DEL CORPO DEL TASK DALLA DLL SUL CORE DEDICATO
        if (context->TaskFunction != nullptr) {
            context->TaskFunction(context->pSharedParcelAddress, inputMap, outputMap);
        }

        QueryPerformanceCounter(&taskEnd);

        // RIPRISTINO DEL LIVELLO DI PRIORITÀ STANDARD DOPO L'ESECUZIONE CRITICA
        SetThreadPriority(hCurrentThread, THREAD_PRIORITY_NORMAL);

        // VALIDAZIONE INLINE DEL WATCHDOG ED APPLICAZIONE SANZIONE
        double elapsedUs = (double)(taskEnd.QuadPart - taskStart.QuadPart) / context->TicksPerUs;
        if (elapsedUs > context->MaxWcetUs) {
            std::cerr << "[🚨 WATCHDOG INLINE] Violazione WCET rilevata su '" << context->NodeName
                      << "': " << elapsedUs << " us (Max: " << context->MaxWcetUs << " us)\n";

            // Se eravamo ad alta priorità, scatta lo sanzionamento terapeutico
            if (InterlockedRead(&context->IsHighPriority) == 1) {
                std::cerr << "[🛡️ SAFE RECOVERY] Sfratto: Task degradato stabilmente a LOW PRIORITY.\n";
                InterlockedExchange(&context->IsHighPriority, 0); // Spostamento atomico a priorità bassa
            }
        }

        // STADIO DI FLUSHING DEI MESSAGGI IN USCITA (USCITA)
        FlushCoreOutput(context->pOutChannelAddress, outputMap, context->NodeName);

        // Aggiornamento rigidamente periodico del tick della scadenza successiva per preservare la fase del tandem
        nextPeriodTicks.QuadPart += context->PeriodTicks;
    }
}
