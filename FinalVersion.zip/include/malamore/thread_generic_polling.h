#pragma once
#include <windows.h>
#include <vector>
#include <unordered_map>
#include <string>

// Struttura dati stile iovec Linux per messaggi a lunghezza variabile
struct MSG2 {
    std::vector<char> Buffer;
    ULONG Dimension;
};

// Mappe di transazione I/O: Chiave ULONG = ID numerico del nodo Mittente/Destinatario
using MessageInputMap  = std::unordered_map<ULONG, MSG2>;
using MessageOutputMap = std::unordered_map<ULONG, MSG2>;

// Firma della funzione di esecuzione esportata dalla DLL del Task Realtime
typedef void (*PFN_EXECUTE_ROUTINE_IO)(void* pParcel, MessageInputMap& inMap, MessageOutputMap& outMap);

// Contesto del Thread passato alla routine generica di polling
struct CorePollingContext {
    std::string NodeName;
    void* pSharedParcelAddress;
    void* pInChannelAddress;
    void* pOutChannelAddress;
    PFN_EXECUTE_ROUTINE_IO TaskFunction;
    ULONG MaxWcetUs;
    double TicksPerUs;
    volatile LONG IsHighPriority; // 1 = High Priority (Time Critical), 0 = Low Priority (Normal)
    volatile LONG KeepRunning;
};

// La funzione generica di polling del Core eseguita dal thread isolato
void CorePollingRoutineGeneric(CorePollingContext* context);
